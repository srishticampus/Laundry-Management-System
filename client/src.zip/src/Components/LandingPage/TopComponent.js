import React from 'react'
import '../../Styles/TopComponent.css'
function TopComponent() {
  return (
    <div>
        <div className='top-compo-img'>
            <div className='top-compo-div1'>
            <span className='top-compo-text1'>Welcome to our laundry service</span>
            </div>
        </div>
    </div>
  )
}

export default TopComponent