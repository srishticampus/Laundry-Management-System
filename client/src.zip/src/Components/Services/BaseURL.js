

export const IMG_BASE_URL = 'http://localhost:4047/';
export const API_BASE_URL = 'http://localhost:4047/laundry_api';

// export const IMG_BASE_URL = 'http://hybrid.srishticampus.in';
// export const API_BASE_URL = 'https://hybrid.srishticampus.in/laundry_api';